var cat = require("cat-me");
var joke = require("knock-knock-jokes");
console.log("From app.js");
console.log(cat());
console.log(joke());