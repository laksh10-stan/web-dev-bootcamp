var comments ={};
comments.data=["fgnbv","fgdvr3t","wewrgfds"];
comments.print = function(){
    this.data.forEach(function(el){
        console.log(el);
    });
};