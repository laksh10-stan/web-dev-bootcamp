var firname = prompt("What is your firstname?");
var lastname = prompt("What is your lastname?");
var age = prompt("How old are you?");
alert("Your name is "+firname+ " "+lastname);
alert("You are "+age+" years old");
console.log("Your name is "+firname+ " "+lastname);
console.log("You are "+age+" years old");
