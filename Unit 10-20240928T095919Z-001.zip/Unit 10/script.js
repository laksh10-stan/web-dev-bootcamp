alert("Hello from the js file!");
var username = prompt("WHATS YOUR NAME");
alert("Nice to meet you " +username);
console.log("Also great to meet you " +username);