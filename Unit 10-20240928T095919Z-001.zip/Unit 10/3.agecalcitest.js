var age = prompt("What's your age?");
console.log("You are roughly "+age*365.25+" days old");
alert("You are roughly "+age*365.25+" days old");